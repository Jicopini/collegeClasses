package main;

import main.Node;

public class LinkedList {
	
	Node start = null, curr = null;
	
	public LinkedList()
	{
		
	}
	
	public void new_node(String _n, String _ssn, float _s)
	{
		if (start == null)
		{
			start = new Node(_n, _ssn, _s);
			curr  = start;
		}
		else
		{
			Node temp = new Node(_n, _ssn, _s);
			curr.set_next(temp);
			curr = curr.get_next();
		}
	}
	
}
