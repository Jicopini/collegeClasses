package main;

//Class to describe employee
public class Node {
	
	String name, ssn;
	float salary;
	Node next = null;
	
	public Node(String _n, String _ssn, float _s)
	{
		name   = _n;
		ssn    = _ssn;
		salary = _s;
	}
	
	public void set_next(Node _n)
	{
		next = _n;
	}
	
	public Node get_next()
	{
		return next;
	}
}
