package main;

public interface Database {
	
	public void store(String _d);
	public void setStoreStrategy(String _s);
}
